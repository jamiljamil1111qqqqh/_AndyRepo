import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys
import urllib, urllib2, re, glob
import shutil
import extras
import extract
import addonfix
import addons
import communitybuilds
import CheckPath
import cache
import time
import downloader
import plugintools
import zipfile
import ntpath
import speedtest
import news

#My variables paths
#from addon.common.addon import Addon
#from addon.common.net import Net
#net=Net()

xbmc_version=xbmc.getInfoLabel("System.BuildVersion"); version=xbmc_version[:4]; print version
AddonTitle     =  "Kodi "+version+" Maintenance"
AddonID        =  'plugin.program.Andy'
ADDON          =  xbmcaddon.Addon(id=AddonID)
#ARTPATH       =  'http://kodimaster.com/wizard/art/' + os.sep
ARTPATH        =  'special://home/addons/'+AddonID+'/art/' + os.sep
packages       = xbmc.translatePath(os.path.join('special://home/addons','packages'))
#
mainurl                ='https://raw.githubusercontent.com/halikus/_AndyRepo/master/'
mainurl_zips           = 'https://raw.githubusercontent.com/halikus/_zip/master/'
mainurl_txt            =mainurl+'_txt/'
mainurl_epg            = 'https://raw.githubusercontent.com/halikus/_epg/master/'
url_EPG_ADDONINI       = mainurl_epg+'addons.ini'
url_EPG_STALKER        = mainurl_epg+'addons_Stalker.ini'
url_m3u                =mainurl_epg+'iptv.m3u'
url_Addon_Data         =mainurl_zips+'Addon_Data.zip'
url_Addon_Data_windows =mainurl_zips+'Addon_Data_Windows.zip'
url_Addon_Data_android =mainurl_zips+'Addon_Data_Android.zip'
url_Repos              =mainurl_zips+'Addons_Repos.zip'
url_Addons             =mainurl_zips+'Addons.zip'
url_Addons_windows     =mainurl_zips+'Addons_Windows.zip'
url_Addons_android     =mainurl_zips+'Addons_Android.zip'
url_Addons_Video       =mainurl_zips+'Addons_Video.zip'
url_Addons_Video_Big   =mainurl_zips+'Addons_Video_Big.zip'#depreciated
shortcutstxt   =mainurl + '_txt/shortcuts.txt'
dropboxtxt     =mainurl + '_txt/dropbox.txt'
#
url_Plexus_windows    =mainurl_zips+'P2PStreams_Plexus_Windows.zip'
url_Plexus_android    =mainurl_zips+'P2PStreams_Plexus_Android.zip'
url_Pulsar            =mainurl_zips+'Pulsar.zip'
url_iStream           =mainurl_zips+'iStream.zip'
url_repository_Andy   =mainurl+'_repo/repository.Andy/repository.Andy-0.0.1.zip'
url_superrepo         =mainurl+'_repo/superrepo.kodi.isengard.repositories/superrepo.kodi.isengard.repositories-0.7.03.zip'
url_superrepo3        =mainurl+'_repo/superrepo.kodi.isengard.external.repositories/superrepo.kodi.isengard.external.repositories-0.7.03.zip'
url_PVR15             =mainurl+'_repo/pvr.iptvsimple.15.extra/pvr.iptvsimple.15.extra-1.11.5.zip'
url_PVR16             =mainurl+'_repo/pvr.iptvsimple.16.extra/pvr.iptvsimple.16.extra-1.12.6.zip'
#
url_Android_External_Player=mainurl_txt+'playercorefactory.xml'
url_XML_SOURCES          =mainurl_txt+'sources.xml'
url_XML_ADVANCEDSETTINGS =mainurl_txt+'advancedsettings.xml'
url_XML_RSS              =mainurl_txt+'RssFeeds.xml'
url_XML_autoexec         =mainurl_txt+'autoexec.py'
url_XML_PASSWORDS        =mainurl_txt+'passwords.xml'
url_XML_favourites       =mainurl_txt+'favourites.xml'
url_XML_0cache           =mainurl_txt+'0cache.xml'
url_XML_tuxenxml         =mainurl_txt+'tuxen.xml'
url_XML_Database         =mainurl_txt+'Database.xml'
url_ZIP_Database         =mainurl_txt+'Database.zip'
url_ZIP_keymaps          =mainurl_txt+'keymaps.zip'

zip          =  ADDON.getSetting('zip')
localcopy    =  ADDON.getSetting('localcopy')
privatebuilds=  ADDON.getSetting('private')
reseller     =  ADDON.getSetting('reseller')
resellername =  ADDON.getSetting('resellername')
resellerid   =  ADDON.getSetting('resellerid')
mastercopy   =  ADDON.getSetting('mastercopy')
username     =  ADDON.getSetting('username')
password     =  ADDON.getSetting('password')
login        =  ADDON.getSetting('login')
trcheck      =  ADDON.getSetting('trcheck')
dialog       =  xbmcgui.Dialog()
dp           =  xbmcgui.DialogProgress()
HOME         =  xbmc.translatePath('special://home/')
USERDATA     =  xbmc.translatePath(os.path.join('special://home/userdata',''))
MEDIA        =  xbmc.translatePath(os.path.join('special://home/media',''))
AUTOEXEC     =  xbmc.translatePath(os.path.join(USERDATA,'autoexec.py'))
AUTOEXECBAK  =  xbmc.translatePath(os.path.join(USERDATA,'autoexec_bak.py'))
ADDON_DATA   =  xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
PLAYLISTS    =  xbmc.translatePath(os.path.join(USERDATA,'playlists'))
DATABASE     =  xbmc.translatePath(os.path.join(USERDATA,'Database'))
THUMBNAILS   =  xbmc.translatePath(os.path.join(USERDATA,'Thumbnails'))
ADDONS       =  xbmc.translatePath(os.path.join('special://home','addons',''))
CBADDONPATH  =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'default.py'))
FANART       =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'fanart.jpg'))
GUISETTINGS  =  os.path.join(USERDATA,'guisettings.xml')
GUI          =  xbmc.translatePath(os.path.join(USERDATA,'guisettings.xml'))
GUIFIX       =  xbmc.translatePath(os.path.join(USERDATA,'guifix.xml'))
INSTALL      =  xbmc.translatePath(os.path.join(USERDATA,'install.xml'))
FAVS         =  xbmc.translatePath(os.path.join(USERDATA,'favourites.xml'))
SOURCE       =  xbmc.translatePath(os.path.join(USERDATA,'sources.xml'))
ADVANCED     =  xbmc.translatePath(os.path.join(USERDATA,'advancedsettings.xml'))
PROFILES     =  xbmc.translatePath(os.path.join(USERDATA,'profiles.xml'))
RSS          =  xbmc.translatePath(os.path.join(USERDATA,'RssFeeds.xml'))
KEYMAPS      =  xbmc.translatePath(os.path.join(USERDATA,'keymaps','keyboard.xml'))
USB          =  xbmc.translatePath(os.path.join(zip))
CBPATH       =  xbmc.translatePath(os.path.join(USB,'Community Builds',''))
cookiepath   =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'cookiejar'))
startuppath  =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'startup.xml'))
tempfile     =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'temp.xml'))
idfile       =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'id.xml'))
idfiletemp   =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'idtemp.xml'))
notifyart    =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'resources/'))
skin         =  xbmc.getSkinDir()
userdatafolder = xbmc.translatePath(os.path.join(ADDON_DATA,AddonID))
GUINEW       =  xbmc.translatePath(os.path.join(userdatafolder,'guinew.xml'))
guitemp      =  xbmc.translatePath(os.path.join(userdatafolder,'guitemp',''))
tempdbpath   =  xbmc.translatePath(os.path.join(USB,'Database'))
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
base='http://www.kodimaster.com/'
VERSION = "0.0.1"
PATH = "Kodi Maintenance" 

#End My variables paths# No reason to edit below here (no paths to fill)
#-----------------------------------------------------------------------------------------------------------------
xbmc.executebuiltin("Container.SetViewMode(500)")


################################
###     Main Menu
################################
def Categories():
    sign = 0
    mainmenu     =  ADDON.getSetting('mainmenu')
    maintenance  =  ADDON.getSetting('maintenance')
    kmintbuilds  =  ADDON.getSetting('kmintbuilds')
#
    extras.addDir('folder','Maintenance','none', 'tools', 'Maintenance.jpg','','','')
    extras.addDir('folder','System Tweaks','none', 'System_Tweaks', 'tweaks.png','','','')
    extras.addDir('','Fix iVue','url','iVue','iVue.jpg','','','')
    extras.addDir('folder','Kodi System Settings','none','Kodi_System','Kodi_Settings.png','','','')
    #extras.addDir('folder','Backup/Restore My Content','none','backup_restore','Backup.png','','','')
    extras.addDir('folder','Extra Addons','none', 'Extra_Addons', 'addon.png','','','')
    extras.addDir('','Factory Reset','url','wipe_xbmc','freshstart.jpg','','','')
    extras.addDir('','Delete Leftovers (Packages Folder)','url','Purge_Packages','package_purge.png','','','')
    extras.addDir('','Force Close','url','kill_kodi','reboot.png','','','')
    extras.addDir('','Install the following in order as desired','none','warning','order.jpg','','','') #77
#
    extras.addDir('folder','[COLOR green]Extra Builds[/COLOR]','none','Extra_Builds','extra_builds.png','','','')
    #if maintenance == 'true':
    #    extras.addDir('folder','[COLOR green]Extra Builds[/COLOR]','none','Extra_Builds','extra_builds.png','','','')
#
    if mainmenu == 'true': 
        extras.addDir('','[COLOR green]Install All[/COLOR]','url', 'Install_All', 'Restore_Full.png','','','')
        extras.addDir('','Repos',url_Repos,'Repos_Backup','Repos.png','','','')
        extras.addDir('','Addon_Data (App Settings)',url_Addon_Data,'Addon_Data_Backup','Addon_Data.png','','','')
        extras.addDir('','Addons',url_Addons,'Addons_Backup','Addons.png','','','')
        extras.addDir('','All xml (Defaults)','url','XML_All_Backup','XML_ALL.png','','','')
#
    if maintenance == 'true':
        extras.addDir('','Sources.xml (Andy HDD shares)',url_XML_Database,'XML_Database','XML_Database.png','','','')
        extras.addDir('','LiveTV',mainurl_zips,'LiveTV','m3u.png','','','')
#


################################
###     Maintenance Menu
################################
def Tools():
    extras.addDir('folder','Add-on Maintenance/Fixes', 'none', 'addonfixes', 'paramedic.png','','','')
    extras.addDir('folder','Clean/Wipe Options', 'none', 'wipetools', 'clean.png','','','')
    #extras.addDir('folder','Backup/Restore My Content','none','backup_restore','Backup.png','','','')
    extras.addDir('folder','Backup Your Content','none','backup_option','Backup.png','','','')
    extras.addDir('folder','Restore Your Content','none','restore_option','Restore.png','','','')
    extras.addDir('','View Log', 'none', 'log', 'log.jpg','','','')
    extras.addDir('folder','Info','none','Info_MENU','FAQ.png','','','')
    extras.addDir('','Help', 'none', 'help', 'help.png','','','')
    extras.addDir('','Settings (This addon)','url','addon_settings','settings.png','','','')
#

################################
###     Info MENU
################################    
def Info_MENU(): 
    extras.addDir('','View Log', 'none', 'log', 'log.jpg','','','')
    extras.addDir('','IP?','url','get_ip','ip.png','','','')
    extras.addDir('','Check Kodi Version', 'none', 'xbmcversion', 'version.png','','','')
    extras.addDir('','Check Storage', 'none', 'check_storage', 'hdd.png','','','')
    extras.addDir('folder','Speed Test', 'none', 'speed_test', 'speed.png','','','')
    extras.addDir('','Log Upload', 'none', 'log_upload', 'upload.png','','','')
    extras.addDir('','News', 'none', 'text_guide', 'news.jpg','','','')
#

################################
###     XML Menu
################################    
def XML_MENU(): 
    extras.addDir('','All xml (Defaults)','url','XML_All_Backup','XML_ALL.png','','','')
    extras.addDir('','Sources.xml (Extra Repos)',url_XML_SOURCES,'XML_SOURCES','XML_SOURCES.png','','','')
    extras.addDir('','AdvancedSettings.xml (Extra Settings)',url_XML_ADVANCEDSETTINGS,'XML_ADVANCEDSETTINGS','XML_ADVANCEDSETTINGS.png','','','')
    extras.addDir('','RSSFeeds.xml',url_XML_RSS,'XML_RSS','XML_RSS.png','','','')
    extras.addDir('','favourites.xml',url_XML_favourites,'XML_favourites','XML.png','','','')
    extras.addDir('','View sources.xml','url','view_sources','XML_SOURCES.png','','','')
    extras.addDir('','View advancedsettings.xml','url','view_advancedxml','XML_ADVANCEDSETTINGS.png','','','')
    extras.addDir('','View RSSFeeds.xml','url','view_RSSFeeds','XML_RSS.png','','','')
    extras.addDir('','View favourites.xml','url','view_favourites','XML.png','','','')
    extras.addDir('','autoexec.py',url_XML_autoexec,'XML_autoexec','XML.png','','','')
#

################################
###     System Tweaks Menu
################################
def System_Tweaks_MENU():
    if xbmc.getCondVisibility('system.platform.android'): extras.addDir('','-Android External Player',url_Android_External_Player,'androidexternalplayer','androidexternalplayer.jpg','','','')#26
    extras.addDir('folder','XML','none','XML_MENU','XML.png','','','')
    extras.addDir('','Convert Physical Paths To Special (User_Data)',HOME,'fix_special','setpath.jpg','','','')
    extras.addDir('folder','XML AdvancedSettings','none', 'AdvancedSettings_menu', 'advancedsettings.jpg','','','')
    extras.addDir('','Shortcuts (Homescreen)','plugin.','shortcuts','shortcut.jpg','','','')
    extras.addDir('','Update Local IPTV M3U',url_m3u+'/iptv.m3u','m3u','m3u.png','','','')
#

################################
###   Extra Addons Menu   
################################
def Extra_Addons_MENU():
    extras.addDir('folder','Remove addon (inc. passwords)','plugin','addon_removal_menu', 'addonremoval.jpg','','','')
    extras.addDir('','Zip Addon Install','url','AddonBrowser','zip.jpg','','','')
    extras.addDir('','Minimal Dependancies','file','Minimal_Dependancies','paramedic.png','','','')
    extras.addDir('','Andy Repo (Install)',url_repository_Andy,'Andy_Repo','Andy_Repo.png','','','')
    extras.addDir('','Super Repo (All)',url_superrepo,'superrepo_isengard_repositories','Repo_SuperRepo.png','','','')
    extras.addDir('','Super Repo (3rd Party)',url_superrepo3,'superrepo_isengard_external_repositories','Repo_SuperRepo3.png','','','')
    extras.addDir('','Plexus and P2P Streams (Full)',url_Plexus_windows,'Plexus','P2PStreams.jpg','','','')
    extras.addDir('','iStream (Xunitytalk)',url_iStream,'iStream','iStream.png','','','')
    extras.addDir('','Pulsar (Slows Kodi))',url_Pulsar,'Pulsar','Pulsar.png','','','')
#

################################
### Advancedsettings XML Menu
################################    
def AdvancedSettings_MENU(): 
    extras.addDir('','View advancedsettings.xml','url','view_advancedxml','verifyadvancedsettings.jpg','','','')
    extras.addDir('','Verify advancedsettings.xml','url','verifyadvancedsettings','verifyadvancedsettings.jpg','','','')
    extras.addDir('','Remove advancedsettings.xml','url','removeadvancedsettings','removeadvancedsettings.jpg','','','')
    extras.addDir('','Add Default advancedsettings.xml',url_XML_ADVANCEDSETTINGS,'add_advancedsettings','advancedsettings.jpg','','','')
    extras.addDir('','Enable Tuxen advancedsettings.xml',url_XML_tuxenxml,'add_tuxen','tuxenxml.jpg','','','')
    extras.addDir('','Enable Zero Caching advancedsettings.xml',url_XML_0cache,'add_0cache','zerocache.jpg','','','')
#

################################
###   Extra Builds Menu   
################################
def Extra_Builds_MENU():
    kmintbuilds  =  ADDON.getSetting('kmintbuilds')
    thirdpartybuilds  =  ADDON.getSetting('thirdpartybuilds')
    adultbuilds  =  ADDON.getSetting('adultbuilds')
    guisettings  =  ADDON.getSetting('guisettings')
    if kmintbuilds == 'true':
        extras.addDir('folder','[COLOR green]Andys Pre-Configured (Default) (Onedrive)[/COLOR]','none', 'kmintmenu', 'Restore_Full.png','','','')
    if thirdpartybuilds == 'true':
        extras.addDir('folder','[COLOR gold]KodiMaster Builds[/COLOR]','none', 'buildmenu', 'KodiMaster_Builds.png','','','')
        extras.addDir('folder','[COLOR blue]Third-Party Builds[/COLOR]','none', 'thirdpartymenu', 'ThirdParty_Builds.png','','','')
        #extras.addDir('folder','[COLOR gold]KodiMaster International Builds[/COLOR]','none', 'kmintmenu', 'KodiMasterInt_Builds.png','','','')
    if adultbuilds == 'true':
        extras.addDir('folder','[COLOR red]Adult Builds[/COLOR]','none', 'adultmenu', 'Adult_Builds.png','','','')
    guisettings  =  ADDON.getSetting('guisettings')
    if guisettings == 'true':
        extras.addDir('folder','Gui Settings XML','none', 'guisettings', 'ThirdParty_Builds.png','','','')
#

################################
###     Wipe_Tools Menu
################################
def Wipe_Tools():
    extras.addDir('','Clear Cache','url','clear_cache','clearcache.jpg','','','')#Clear_Cache.png
    extras.addDir('','Clear My Cached Artwork', 'none', 'remove_textures', 'thumb.png','','','')#Delete_Cached_Artwork.png
    extras.addDir('','Delete Addon_Data','url','remove_addon_data','Profile.png','','','')#Delete_Addon_Data.png
    extras.addDir('','Purge Packages Folder','url','remove_packages','package_purge.png','','','')#Delete_Packages.png
    extras.addDir('folder','Completely remove addon (inc. passwords)','plugin','addon_removal_menu', 'addonremoval.jpg','','','')
    extras.addDir('','Delete Old Builds/Zips From Device','url','remove_build','delete.jpg','','','')#Delete_Builds.png
    extras.addDir('','Delete Old Crash Logs','url','remove_crash_logs','eraselogs.jpg','','','')#Delete_Crash_Logs.png
    extras.addDir('','Wipe My Install (Fresh Start)', 'none', 'wipe_xbmc', 'freshstart.jpg','','','')#Fresh_Start.png
#

#Addon Maintenance Section
################################
###     Addon_Fixes Menu
################################
def Addon_Fixes():
    extras.addDir('folder','Completely remove an add-on (inc. passwords)','plugin','addon_removal_menu', 'delete.jpg','','','')#Remove_Addon.png
    extras.addDir('','Wipe All Add-on Settings (addon_data)','url','remove_addon_data','clean.png','','','')#Delete_Addon_Data.png
    extras.addDir('','Update My Add-ons (Force Refresh)', 'none', 'update', 'addon.png','','','')#Update_Addons.png
    extras.addDir('','Hide my add-on passwords','none','hide_passwords', 'Lock.png','','','')#Hide_Passwords.png
    extras.addDir('','Unhide my add-on passwords','none','unhide_passwords', 'Unlock.png','','','')#Unhide_Passwords.png
    extras.addDir('','Needed Modules','file','Modules','paramedic.png','','','')
#

################################
###     Backup/Restore Menu
################################
def Backup_Restore():
    extras.addDir('folder','Backup My Content','none','backup_option','Backup.png','','','')
    extras.addDir('folder','Restore My Content','none','restore_option','Restore.png','','','')
#

################################
###     Addon removal Menu
################################
def Addon_Removal_Menu():
    for file in glob.glob(os.path.join(ADDONS,'*')):
        name=str(file).replace(ADDONS,'[COLOR=red]REMOVE [/COLOR]').replace('plugin.','[COLOR=dodgerblue](PLUGIN) [/COLOR]').replace('audio.','').replace('video.','').replace('skin.','[COLOR=yellow](SKIN) [/COLOR]').replace('repository.','[COLOR=orange](REPOSITORY) [/COLOR]').replace('script.','[COLOR=cyan](SCRIPT) [/COLOR]').replace('metadata.','[COLOR=gold](METADATA) [/COLOR]').replace('service.','[COLOR=pink](SERVICE) [/COLOR]').replace('weather.','[COLOR=green](WEATHER) [/COLOR]').replace('module.','[COLOR=gold](MODULE) [/COLOR]')
        iconimage=(os.path.join(file,'icon.png'))
        fanart=(os.path.join(file,'fanart.jpg'))
        extras.addDir('',name,file,'remove_addons',iconimage,fanart,'','')
#

################################
###     Speed test Menu
################################
def Speed_Test_Menu():
    #import speedtest
    extras.addDir('','Download 16MB file   - [COLOR=lime]Server 1[/COLOR]', 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/16MB.txt', 'runtest', 'speed.png','','','')
    extras.addDir('','Download 32MB file   - [COLOR=lime]Server 1[/COLOR]', 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/32MB.txt', 'runtest', 'speed.png','','','')
    extras.addDir('','Download 64MB file   - [COLOR=lime]Server 1[/COLOR]', 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/64MB.txt', 'runtest', 'speed.png','','','')
    extras.addDir('','Download 128MB file -  [COLOR=lime]Server 1[/COLOR]', 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/128MB.txt', 'runtest', 'speed.png','','','')
    extras.addDir('','Download 10MB file   - [COLOR=yellow]Server 2[/COLOR]', 'http://www.wswd.net/testdownloadfiles/10MB.zip', 'runtest', 'speed.png','','','')
#

################################
###     Kodi_System Menu
################################
def Kodi_System_MENU():
#http://kodi.wiki/view/Keymaps
    extras.addDir('','Settings','url','systemsettings','settings.png','','','')
    extras.addDir('','File Manager','none','filemanager','file_manager.png','','','')
    extras.addDir('','System Info','url','systeminfo','FAQ.png','','','')
    extras.addDir('','Zip Addon Install','url','AddonBrowser','zip.jpg','','','')
    extras.addDir('','Skin Settings','url','skinsettings','theme.png','','','')
    extras.addDir('','Profiles','url','profiles','Profile.png','','','')
    extras.addDir('','Appearance Settings','url','appearancesettings','thumb.png','','','')
    extras.addDir('','Video Settings','url','videossettings','1.jpg','','','')
    extras.addDir('','PVR Settings','url','pvrsettings','1.jpg','','','')
    extras.addDir('','Music Settings','url','musicsettings','1.jpg','','','')
    extras.addDir('','Weather Settings','url','weathersettings','1.jpg','','','')
    extras.addDir('','Service Settings','url','servicesettings','1.jpg','','','')
    extras.addDir('','Screen Calibration','url','screencalibration','1.jpg','','','')
#

################################
###     Function to open addon settings
################################
def Addon_Settings():
    ADDON.openSettings(sys.argv[0])
#

################################
###     Function to clear all known cache files
################################
def Clear_Cache():
    choice = xbmcgui.Dialog().yesno('Clear All Known Cache?', 'This will clear all known cache files and can help', 'if you\'re encountering kick-outs during playback.','as well as other random issues. There is no harm in using this.', nolabel='Cancel',yeslabel='Delete')
    if choice == 1:
        cache.Wipe_Cache()
        Remove_Textures()
#---------------------------------------------------------------------------------------------------
#Get params and clean up into string or integer
def Get_Params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
#

################################
###     Function to clear the addon_data
################################
def Remove_Addon_Data():
    choice = xbmcgui.Dialog().yesno('Delete Addon_Data Folder?', 'This will free up space by deleting your addon_data', 'folder. This contains all addon related settings', 'including username and password info.', nolabel='Cancel',yeslabel='Delete')
    if choice == 1:
        extras.Delete_Userdata()
        dialog.ok("Addon_Data Removed", '', 'Your addon_data folder has now been removed.','')
#

################################
###     Function to Remove_Crash_Logs
################################
def Remove_Crash_Logs():
    choice = xbmcgui.Dialog().yesno('Remove All Crash Logs?', 'There is absolutely no harm in doing this, these are', 'log files generated when Kodi crashes and are','only used for debugging purposes.', nolabel='Cancel',yeslabel='Delete')
    if choice == 1:
        extras.Delete_Logs()
        dialog.ok("Crash Logs Removed", '', 'Your crash log files have now been removed.','')
#

################################
###     Function to clear the packages folder
################################
def Remove_Packages():
    choice = xbmcgui.Dialog().yesno('Delete Packages Folder?', 'This will free up space by deleting the zip install', 'files of your addons. The only downside is you\'ll no', 'longer be able to rollback to older versions.', nolabel='Cancel',yeslabel='Delete')
    if choice == 1:
        extras.Delete_Packages()
        #dialog.ok("Packages Removed", '', 'Your zip install files have now been removed.','')
#

################################
###     Function to clear the thumbnails folder
################################
def Remove_Textures():
    choice = xbmcgui.Dialog().yesno('Clear Cached Images?', 'This will clear your textures13.db file and remove', 'your Thumbnails folder. These will automatically be', 'repopulated after a restart.', nolabel='Cancel',yeslabel='Delete')
    if choice == 1:
        cache.Remove_Textures()
        extras.Destroy_Path(THUMBNAILS)
        choice = xbmcgui.Dialog().yesno('Quit Kodi Now?', 'Cache has been successfully deleted.', 'You must now restart Kodi, would you like to quit now?','', nolabel='I\'ll restart later',yeslabel='Yes, quit')
        if choice == 1:
            killkodi()
#

################################
###     Fresh Start (Wipe Kodi)
################################
def Wipe_Kodi():
    mybackuppath = xbmc.translatePath(os.path.join(USB,'Community Builds','My Builds'))
    choice = xbmcgui.Dialog().yesno("ABSOLUTELY CERTAIN?!!!", 'Are you absolutely certain you want to wipe?', '', 'All addons and settings will be completely wiped!', yeslabel='Yes',nolabel='No')
    if choice == 1:
        if skin!= "skin.confluence":
            dialog.ok(AddonTitle,'Please switch to the default Confluence skin','before performing a wipe.','')
            xbmc.executebuiltin("ActivateWindow(appearancesettings)")
            return
        else:
            choice = xbmcgui.Dialog().yesno("VERY IMPORTANT", 'This will completely wipe your install.', 'Would you like to create a backup before proceeding?', '', yeslabel='No', nolabel='Yes')
            if choice == 0:
                if not os.path.exists(mybackuppath):
                    os.makedirs(mybackuppath)
                vq = extras.Get_Keyboard( heading="Enter a name for this backup" )
                if ( not vq ): return False, 0
                title = urllib.quote_plus(vq)
                backup_zip = xbmc.translatePath(os.path.join(mybackuppath,title+'.zip'))
                exclude_dirs_full =  ['plugin.program.Andy']
                exclude_files_full = ["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log",'.DS_Store','.setup_complete','XBMCHelper.conf']
                message_header = "Creating full backup of existing build"
                message1 = "Archiving..."
                message2 = ""
                message3 = "Please Wait"
                communitybuilds.Archive_Tree(HOME, backup_zip, message_header, message1, message2, message3, exclude_dirs_full, exclude_files_full)
            choice = xbmcgui.Dialog().yesno("Remove "+AddonTitle+"?", 'Do you also want to remove this addon', 'and have a complete fresh start or would you', 'prefer to keep this on your system?', yeslabel='Remove',nolabel='Keep')
            if choice == 0:
                cache.Remove_Textures()
                trpath = xbmc.translatePath(os.path.join(ADDONS,AddonID,''))
                trtemp = xbmc.translatePath(os.path.join(HOME,'..',AddonID+'.zip'))
                communitybuilds.Archive_File(trpath, trtemp)
                deppath = xbmc.translatePath(os.path.join(ADDONS,'script.module.addon.common',''))
                deptemp = xbmc.translatePath(os.path.join(HOME,'..','script.module.addon.common.zip'))
                communitybuilds.Archive_File(deppath, deptemp)
                extras.Destroy_Path(HOME)
                if not os.path.exists(trpath):
                    os.makedirs(trpath)
                if not os.path.exists(deppath):
                    os.makedirs(deppath)
                time.sleep(1)
                communitybuilds.Read_Zip(trtemp)
                dp.create(AddonTitle,"Checking ",'', 'Please Wait')
                dp.update(0,"", "Extracting Zip Please Wait")
                extract.all(trtemp,trpath,dp)
                communitybuilds.Read_Zip(deptemp)
                extract.all(deptemp,deppath,dp)
                dp.update(0,"", "Extracting Zip Please Wait")
                dp.close()
                time.sleep(1)
                extras.Kill_XBMC()
            elif choice == 1:
                cache.Remove_Textures()
                extras.Destroy_Path(HOME)
                dp.close()
                extras.Kill_XBMC()
            else: return
#

################################
###     Builds Section
################################
def BuildMenu():
    link = OPEN_URL('http://kodimaster.com/wizard/kodimasterbuilds.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,'wizard',iconimage,fanart,description)
    setView('movies', 'MAIN')
	
def KMIntMenu():
    #link = OPEN_URL('http://kodimaster.com/wizard/kmintbuilds.txt').replace('\n','').replace('\r','')
    link = OPEN_URL(dropboxtxt).replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,'wizard',iconimage,fanart,description)
    setView('movies', 'MAIN')
	
def ThirdPartyMenu():
    link = OPEN_URL('http://kodimaster.com/wizard/thirdpartybuilds.txt').replace('\n','').replace('\r','')
    #link = OPEN_URL(mainurl + '_txt/thirdpartybuilds.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,'wizard',iconimage,fanart,description)
    setView('movies', 'MAIN')
	
def AdultMenu():
    link = OPEN_URL('http://kodimaster.com/wizard/adultbuilds.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,'wizard',iconimage,fanart,description)
    setView('movies', 'MAIN')
	
def guisettings():
    link = OPEN_URL('http://kodimaster.com/wizard/guisettings.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,'wizard',iconimage,fanart,description)
    setView('movies', 'MAIN')
	
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link  
    
def wizard(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("Install Wizard ","Downloading ",'', 'Please Wait')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Extracting Zip Please Wait")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok("DOWNLOAD COMPLETE", 'To ensure all changes are saved you must now close Kodi', 'to force close Kodi. Click ok,', 'DO NOT use the quit/exit options in Kodi.')
    killkodi()
#

################################
###     Kill Kodi
################################
def killkodi():
    choice = xbmcgui.Dialog().yesno('Force Close Kodi', 'You are about to close Kodi', 'Would you like to continue?', nolabel='No, Cancel',yeslabel='Yes, Close')
    if choice == 0:
        return
    elif choice == 1:
        pass
    myplatform = platform()
    print "Platform: " + str(myplatform)
    if myplatform == 'osx': # OSX
        print "############   try osx force close  #################"
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'linux': #Linux
        print "############   try linux force close  #################"
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'android': # Android  
        print "############   try android force close  #################"
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass        
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "Your system has been detected as Android, you ", "[COLOR=yellow][B]MUST[/COLOR][/B] force close XBMC/Kodi. [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Pulling the power cable is the simplest method to force close.")
    elif myplatform == 'windows': # Windows

        print "############   try windows force close  #################"
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im pulsar.exe /f')          
            os.system('tskill pulsar.exe')  
            os.system('TASKKILL /im Kodi.exe /f')          
            os.system('tskill Kodi.exe')          
            os.system('TASKKILL /im XBMC.exe /f')  
            os.system('tskill XBMC.exe')
        except: pass
        
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","Your platform could not be detected so just pull the power cable.")    
#
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
#
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
#

################################
###     Purge Packages       ###
################################
def PURGEPACKAGES():
    print '###'+AddonTitle+' - DELETING PACKAGES###'
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0:
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                    #dialog = xbmcgui.Dialog()
                    #dialog.ok(AddonTitle, "       Deleting Packages all done")
                else:
                        pass
            else:
                dialog = xbmcgui.Dialog()
                dialog.ok(AddonTitle, "       No Packages to Purge")
    except:
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "Error Deleting Packages")
#

################################
###          Get IP           ###
################################
def Get_IP(url='http://www.iplocation.net/',inc=1):
    from addon.common.net import Net
    net=Net()
    xbmc_version=xbmc.getInfoLabel("System.BuildVersion"); version=xbmc_version[:4]; print version
    match=re.compile("<td width='80'>(.+?)</td><td>(.+?)</td><td>(.+?)</td><td>.+?</td><td>(.+?)</td>").findall(net.http_GET(url).content)
    for ip, region, country, isp in match:
        if inc <2: dialog=xbmcgui.Dialog(); dialog.ok("Your Kodi version is: %s" % version, "[B][COLOR gold]Your IP Address is: [/COLOR][/B] %s" % ip, '[B][COLOR gold]Your IP is based in: [/COLOR][/B] %s' % country, '[B][COLOR gold]Your Service Provider is:[/COLOR][/B] %s' % isp)
        inc=inc+1
#

################################
###   PATH_ADDON             ###
################################
def PATH_ADDON(url, addontempname,addonpath):
    pluginpath = os.path.exists(xbmc.translatePath(os.path.join('special://home','addons',"packages",addontempname + ".zip")))
    if pluginpath: #exit #dialog=xbmcgui.Dialog()#; dialog.ok(AddonTitle,addontempname + " is installed.")#; xbmc.executebuiltin("RunAddon(%s)" % addontempname)
        print '=== Installing ' +addontempname+ ' Start ===';
        path=xbmc.translatePath(os.path.join('special://home','addons','packages'))
        lib=os.path.join(path,addontempname+'.zip')
        addonfolder=xbmc.translatePath(os.path.join('special://',addonpath,'')); dp=xbmcgui.DialogProgress(); dp.create(AddonTitle, "Extracting "+addontempname+".zip","Please Wait.")
        extract.all(lib,addonfolder,dp)
        print '=== Installing ' +addontempname+ ' Success ===';
    
    else:
        print '=== Installing ' +addontempname+ ' Start ===';
        path=xbmc.translatePath(os.path.join('special://home','addons','packages'))
        lib=os.path.join(path,addontempname+'.zip')
        DownloaderClass(url,lib,addontempname)
        time.sleep(1)
        print '=== INSTALLING '+ addontempname +' Addon ===';
        addonfolder=xbmc.translatePath(os.path.join('special://',addonpath,'')); dp=xbmcgui.DialogProgress(); dp.create(AddonTitle, "Extracting "+addontempname+".zip","Please Wait.")
        extract.all(lib,addonfolder,dp)
        #xbmc.executebuiltin("UpdateLocalAddons()"); xbmc.executebuiltin("UpdateAddonRepos()")
        print '=== Installing ' +addontempname+ ' Success ===';
        #dialog=xbmcgui.Dialog(); dialog.ok(AddonTitle,"Done Installing "+addontempname)       
#

################################
###   PATH_ADDON_PROMPTS     ###
################################
def PATH_ADDON_PROMPTS(url, addontempname,addonpath):
    pluginpath = os.path.exists(xbmc.translatePath(os.path.join('special://home','addons',"packages",addontempname + ".zip")))
    if pluginpath:
        dialog=xbmcgui.Dialog();
        dialog.ok(AddonTitle,addontempname + " is installed.")
        #; xbmc.executebuiltin("RunAddon(%s)" % addontempname)
    else:
        print '=== Installing ' +addontempname+ ' Start ===';
        path=xbmc.translatePath(os.path.join('special://home','addons','packages'))
        lib=os.path.join(path,addontempname+'.zip')
        DownloaderClass(url,lib,addontempname)
        print '=== INSTALLING '+ addontempname +' Addon ===';
        addonfolder=xbmc.translatePath(os.path.join('special://',addonpath,'')); dp=xbmcgui.DialogProgress(); dp.create(AddonTitle, "Extracting "+addontempname+".zip","Please Wait.")
        extract.all(lib,addonfolder,dp)
        #xbmc.executebuiltin("UpdateLocalAddons()"); xbmc.executebuiltin("UpdateAddonRepos()")
        print '=== Installing ' +addontempname+ ' Success ===';
        dialog=xbmcgui.Dialog(); dialog.ok(AddonTitle,"Done Installing "+addontempname)
        #if dialog.yesno("Done Installing "+addontempname, 'Do you wish to refresh addons?'):
        #    xbmc.executebuiltin("UpdateLocalAddons()"); xbmc.executebuiltin("UpdateAddonRepos()")
        xbmc.executebuiltin("UpdateLocalAddons()"); xbmc.executebuiltin("UpdateAddonRepos()")
#

################################
###      #Check if DEPENDANCIES is installed, install if it doesn't exist for future updates
################################
def DEPENDANCIES_FILE(file):
        pc_archive=xbmc.translatePath(os.path.join('special://home','addons',AddonID,'resources','help',file+'.zip'))
        pc_addonfolder=xbmc.translatePath(os.path.join('special://home','addons',''))
        if not os.path.exists(xbmc.translatePath(os.path.join('special://home','addons',file))): extract.all(pc_archive,pc_addonfolder)#; xbmc.executebuiltin("UpdateLocalAddons()"); xbmc.executebuiltin("UpdateAddonRepos()")
        #dialog=xbmcgui.Dialog(); dialog.ok(AddonTitle,"Done Installing DEPENDANCIES") 
###   End DEPENDANCIES      ###
#

################################
###   Install  XML  with Prompt  
################################
def ADVANCEDXML_PROMPT(url,name,file):
    import advancedsettings
    from addon.common.net import Net
    net=Net()
    #path = xbmc.translatePath(os.path.join('special://home/userdata',''))
    path = xbmc.translatePath(os.path.join('special://profile',''))
    advance=os.path.join(path, file)
    dialog = xbmcgui.Dialog()
    bak=os.path.join(path, file+'.bak')
    if os.path.exists(bak)==False:
        if dialog.yesno("Back Up Original", 'Have You Backed Up Your '+file+'?','', "[B][COLOR red]     AS YOU CANNOT GO BACK !!![/B][/COLOR]"):
            print '### '+AddonTitle+' - '+file+'###'
            #path = xbmc.translatePath(os.path.join('special://home/userdata',''))
            path = xbmc.translatePath(os.path.join('special://profile',''))
            advance=os.path.join(path, file)
            try:
                os.remove(advance)
                print '=== Maintenance Tool - REMOVING    '+str(advance)+'    ==='
            except:
                pass
            link=net.http_GET(url).content
            a = open(advance,"w")
            a.write(link)
            a.close()
            print '=== Maintenance Tool - WRITING NEW    '+str(advance)+'    ==='
            dialog = xbmcgui.Dialog()
            dialog.ok(AddonTitle, "       Done Adding new "+file)
    else:
        print '###'+AddonTitle+' - '+file+'###'
        #path = xbmc.translatePath(os.path.join('special://home/userdata',''))
        path = xbmc.translatePath(os.path.join('special://profile',''))
        advance=os.path.join(path, file)
        try:
            os.remove(advance)
            print '=== Maintenance Tool - REMOVING    '+str(advance)+'    ==='
        except:
            pass
        link=net.http_GET(url).content
        a = open(advance,"w")
        a.write(link)
        a.close()
        print '=== Maintenance Tool - WRITING NEW    '+str(advance)+'    ==='
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "       Done Adding new "+file)
################################
###       Install  XML       ###
################################
def ADVANCEDXML(url,name,file):
    import advancedsettings
    from addon.common.net import Net
    net=Net()
    #path = xbmc.translatePath(os.path.join('special://home/userdata',''))
    path = xbmc.translatePath(os.path.join('special://profile',''))
    advance=os.path.join(path, file)
    bak=os.path.join(path, file+'.bak')
    if os.path.exists(bak)==False:
        print '### '+AddonTitle+' - '+file+'###'
        #path = xbmc.translatePath(os.path.join('special://home/userdata',''))
        path = xbmc.translatePath(os.path.join('special://profile',''))
        advance=os.path.join(path, file)
        try:
            os.remove(advance)
            print '=== Maintenance Tool - REMOVING    '+str(advance)+'    ==='
        except:
            pass
        link=net.http_GET(url).content
        a = open(advance,"w")
        a.write(link)
        a.close()
        print '=== Maintenance Tool - WRITING NEW    '+str(advance)+'    ==='
    else:
        print '###'+AddonTitle+' - '+file+'###'
        #path = xbmc.translatePath(os.path.join('special://home/userdata',''))
        path = xbmc.translatePath(os.path.join('special://profile',''))
        advance=os.path.join(path, file)
        try:
            os.remove(advance)
            print '=== Maintenance Tool - REMOVING    '+str(advance)+'    ==='
        except:
            pass
        link=net.http_GET(url).content
        a = open(advance,"w")
        a.write(link)
        a.close()
        print '=== Maintenance Tool - WRITING NEW    '+str(advance)+'    ==='
################################
###       check Advanced XML
################################
def CHECKADVANCEDXML(url,name):
    print '###'+AddonTitle+' - CHECK ADVANCE XML###'
    #path = xbmc.translatePath(os.path.join('special://home/userdata',''))
    path = xbmc.translatePath(os.path.join('special://profile',''))
    advance=os.path.join(path, 'advancedsettings.xml')
    try:
        a=open(advance).read()
        if 'zero' in a:
            name='Zero Caching'
        elif 'tuxen' in a:
            name='TUXENS'
    except:
        name="NO ADVANCED"
    dialog = xbmcgui.Dialog()
    dialog.ok(AddonTitle,"[COLOR yellow]YOU HAVE[/COLOR] "+ name+"[COLOR yellow] SETTINGS SETUP[/COLOR]")
################################
###       delete Advanced XML
################################
def DELETEADVANCEDXML(url):
    print '###'+AddonTitle+' - DELETING ADVANCE XML###'
    #path = xbmc.translatePath(os.path.join('special://home/userdata',''))
    path = xbmc.translatePath(os.path.join('special://profile',''))
    advance=os.path.join(path, 'advancedsettings.xml')
    try:
        os.remove(advance)
        dialog = xbmcgui.Dialog()
        print '=== Maintenance Tool - DELETING    '+str(advance)+'    ==='
        dialog.ok(AddonTitle, "       Remove Advanced Settings Sucessfull")
    except:
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "       No Advanced Settings To Remove")
###     End Advanced XML     ###
#

################################
#     Option to upload a log
################################
def Upload_Log(): 
    if ADDON.getSetting('email')=='':
        dialog = xbmcgui.Dialog()
        dialog.ok("No Email Address Set", "A new window will Now open for you to enter your", "Email address. The logfile will be sent here")
        ADDON.openSettings()
    xbmc.executebuiltin('XBMC.RunScript(special://home/addons/plugin.program.Andy/uploadLog.py)')
#

################################
#     Option to open a log
################################
def File_Viewer(path,file):
    log_path = xbmc.translatePath(path)
    log = os.path.join(log_path, file)
    extras.Text_Boxes(file, log)
#

################################
###   Open Kodi Settings     ###
################################
def Open_Kodi_Settings(open_settings):
    #xbmc.executebuiltin("StopScript(%s)" % addon_id)
    #dialog=xbmcgui.Dialog(); dialog.ok(AddonTitle,"This will take you to "+open_settings+" settings menu."," ", "Use the back button to return to the Maintenance Menu.")
    #xbmc.executebuiltin("ActivateWindow(AddonBrowser)")
    xbmc.executebuiltin("ActivateWindow("+open_settings+")")
#

################################
#     Install All Backups
################################
def Install_All(): 
    dialog = xbmcgui.Dialog()
    if dialog.yesno("Restore Backup?", 'Do you want to restore?','', "[B][COLOR red]     AS YOU CANNOT GO BACK !!![/B][/COLOR]"):
    
        PATH_ADDON(url_Addon_Data, 'Addon_Data', 'profile/addon_data')
        myplatform = platform()
        print "Platform: " + str(myplatform)
        if myplatform == 'osx': # OSX
            print "############   osx  #################"

        elif myplatform == 'linux': #Linux
            print "############  linux  #################"

        elif myplatform == 'android': # Android  
            print "############   android  #################"
            PATH_ADDON(url_Addon_Data_android, 'Addon_Data_Android', 'profile/addon_data')
        
        elif myplatform == 'windows': # Windows
            print "############   Windows  #################"
            PATH_ADDON(url_Addon_Data_windows, 'Addon_Data_Windows', 'profile/addon_data')
        
        communitybuilds.Fix_Special(HOME)
        PATH_ADDON(url_Repos, 'Addons_Repos', 'home/addons')
        xbmc.executebuiltin("UpdateAddonRepos")
        #PATH_ADDON(url_Addons, 'Addons', 'home/addons')
        #PATH_ADDON(url_Addons_Video, 'Addons_Video', 'home/addons')
        #PATH_ADDON(url_Addons_Video_Big, 'Addons_Video_Big', 'home/addons')
        SHORTCUTS()
        ADVANCEDXML(url_XML_SOURCES,name,'sources.xml')
        ADVANCEDXML(url_XML_ADVANCEDSETTINGS,name,'advancedsettings.xml')
        ADVANCEDXML(url_XML_RSS,name,'RssFeeds.xml')
        PATH_ADDON(url_ZIP_Database, 'Database', 'userdata/Database')
        PATH_ADDON(url_ZIP_keymaps, 'keymaps', 'userdata/keymaps')
        #ADVANCEDXML(url_XML_favourites,name,'favourites.xml')
        ADDONS_ALL()
        #LiveTV()
            
        #Remove_Packages()
        #if dialog.yesno("Done", 'Do you wish to refresh addons?  (Unnessessary)'):
        #    xbmc.executebuiltin("UpdateLocalAddons()"); xbmc.executebuiltin("UpdateAddonRepos()")
        killkodi()
        #Have beer
#

################################
###      Shortcuts Install   ###
################################
def SHORTCUTS():
        print '=== Installing Pre-Configured Backup Shortcuts ===';
        link=OPEN_URL(shortcutstxt)
        shorts=re.compile('shortcut="(.+?)"').findall(link)
        for shortname in shorts: xEB('Skin.SetString(%s)'%shortname)
        #xEB('Skin.SetString(CustomBackgroundPath,%s)' %img)
        #xEB('Skin.SetBool(ShowBackgroundVideo)')       ## Set to true so we can later set them to false.
        #xEB('Skin.SetBool(ShowBackgroundVis)')         ## Set to true so we can later set them to false.
        #xEB('Skin.ToggleSetting(ShowBackgroundVideo)') ## Switching from true to false.
        #xEB('Skin.ToggleSetting(ShowBackgroundVis)')   ## Switching from true to false.
        #xEB('general.ToggleSetting(settinglevel)')
        #xEBb('HideBackGroundFanart')
        #xEBb('HideVisualizationFanart')
        xEBb('AutoScroll')
        #xEBS('CustomBackgroundPath',SkinBackGroundImg)
        #xEBb('UseCustomBackground')
        print '=== Installing shortcuts Success ===';
        #dialog=xbmcgui.Dialog(); dialog.ok(AddonTitle,"Done Installing Homescreen Shortcuts") 
###  End Shortcuts Install     ###
#

################################
###      Modules Install    ###    ?
################################
def Install_Modules(): 
    dependencies = ['script.module.addon.common','repository.Andy','plugin.program.forceclose']
    for scripts in dependencies:
        addon=xbmc.translatePath(os.path.join('special://home/addons',scripts))
        if os.path.exists(addon)==False:
            dp = xbmcgui.DialogProgress()
            dp.create("Modules","Downloading ",scripts, 'Please Wait')
            lib=os.path.join(packages,scripts+'.zip')
            #downloader.download('http://xfinity.xunitytalk.com/Modules/%s.zip'%scripts, lib, dp)
            downloader.download(url_modules+'/_Modules/%s.zip'%scripts, lib, dp)
            dp.update(0,name, "Extracting Zip Please Wait")
            extract.all(os.path.join(lib),addonfolder,dp)
#


################################
###    ADDONS_ALL Install    ### 
################################
def ADDONS_ALL():
    #dialog = xbmcgui.Dialog()
    #if dialog.yesno("Restore Backup?", 'Do you want to restore Addons?'):
        PATH_ADDON(url_Addons, 'Addons', 'home/addons')
        PATH_ADDON(url_Addons_Video, 'Addons_Video', 'home/addons')
        #PATH_ADDON(url_Addons_Video_Big, 'Addons_Video_Big', 'home/addons')
        
        myplatform = platform()
        print "Platform: " + str(myplatform)
        if myplatform == 'osx': # OSX
            print "############   osx  #################"

        elif myplatform == 'linux': #Linux
            print "############  linux  #################"

        elif myplatform == 'android': # Android  
            print "############   android  #################"
            PATH_ADDON(url_Addons_android, 'Addons_android', 'home/addons')
            #PATH_ADDON(url_Plexus_android, 'Plexus_android', '')
        
        elif myplatform == 'windows': # Windows
            print "############   Windows  #################"
            PATH_ADDON(url_Addons_windows, 'Addons_windows', 'home/addons')
            #PATH_ADDON(url_Plexus_windows, 'Plexus_windows', '')
        
            if dialog.yesno("Restore Pulsar?", 'PC ONLY. Do you want to restore?','', "It slows Kodi down a bit, but add torrent streaming support."):
                PATH_ADDON(url_Pulsar, 'Pulsar', 'home/addons')              
            #LiveTV()
       
        #LiveTV()           
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmc.executebuiltin('SendClick(AddonBrowser, 5)')
        #xbmc.executebuiltin("UpdateLocalAddons()"); xbmc.executebuiltin("UpdateAddonRepos()")
        Remove_Packages()
#




def iVue():
    iVue_Fix("script.tvguidetecbox.Networks",url_EPG_ADDONINI,mainurl_epg + '_iVue_Networks_settings.xml')
    iVue_Fix("script.tvguidetecbox.NetworksExtra",url_EPG_ADDONINI,mainurl_epg + '_iVue_Networks_settings.xml')
    iVue_Fix("script.tvguidetecbox",url_EPG_ADDONINI,mainurl_epg + '_iVue_techbox_settings.xml')
    iVue_Fix("script.tvguidetecbox.Kids",url_EPG_ADDONINI,mainurl_epg + '_iVue_Kids_settings.xml')
    iVue_Fix("script.tvguidetecbox.Sports",url_EPG_ADDONINI,mainurl_epg + '_iVue_Sports_settings.xml')
    iVue_Fix("script.tvguidetecbox.Stalker",url_EPG_ADDONINI,mainurl_epg + '_iVue_Stalker_settings.xml')   
    iVue_Fix("script.tvguidetecbox.UK",url_EPG_ADDONINI,mainurl_epg + '_iVue_UK_settings.xml')    
    iVue_Fix("script.tvguidetecbox.USA",url_EPG_ADDONINI,mainurl_epg + '_iVue_USA_settings.xml')    
    dialog = xbmcgui.Dialog()
    dialog.ok(AddonTitle, "Done fixing the iVue LiveTV addons.ini")  
#

def iVue_Fix(addon,url1,url2):
    pluginpath = os.path.exists(xbmc.translatePath(os.path.join('special://profile','addon_data',addon,"settings.xml")))
    #if pluginpath: ADVANCEDXML(url2,name,'addon_data/'+addon+'/settings.xml')    
    if pluginpath: ADVANCEDXML(url2,addon,'addon_data/'+addon+'/settings.xml')   
     
    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'source5.db')
    try:
       os.remove(lib)
    except:
       pass

    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'guide.xml')
    try:
       os.remove(lib)
    except:
       pass

    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'master.xml')
    try:
       os.remove(lib)
    except:
       pass

    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'Sports.xml')
    try:
       os.remove(lib)
    except:
       pass


    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'Networks.xml')
    try:
       os.remove(lib)
    except:
       pass


    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'Stalker.xml')
    try:
       os.remove(lib)
    except:
       pass

       
    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'addons.ini')
    try:
       os.remove(lib)
    except:
       pass

    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'addons.ini')
    try:
       #ADVANCEDXML(mainurl_epg + '_iVue_Networks_settings.xml',name,lib)
       #DownloaderClass(url,lib2,addontempname)
       DownloaderClass(url1,lib,addon)
       time.sleep(1)
    except:
       pass

def delete_file(filename):
    tries = 10
    while os.path.exists(filename) and tries > 0:
        try:
            os.remove(filename)
            break
        except:
            tries -= 1
   





#not used
def LiveTV():
    dialog = xbmcgui.Dialog()
    if dialog.yesno("LiveTV", 'Do you want to install the iVue LiveTV feature?'):
        xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
        version=float(xbmc_version[:4])
        if version < 16:
            PATH_ADDON(url_PVR15, 'PVR15', 'home/addons');xbmc.executebuiltin('SendClick(AddonBrowser, 5)');Open_Kodi_Settings('pvrsettings')
        else:
            PATH_ADDON(url_PVR16, 'PVR16', 'home/addons');xbmc.executebuiltin('SendClick(AddonBrowser, 5)');Open_Kodi_Settings('pvrsettings')

        #xbmc.executebuiltin('SendClick(AddonBrowser, 5)')
        #PATH_ADDON(url, 'PVR', ''); xbmc.executebuiltin('SendClick(AddonBrowser, 5)')
        #Open_Kodi_Settings('pvrsettings')#;Open_Kodi_Settings('AddonBrowser')
        #Open_Kodi_Settings('skinsettings')
        #Open_Kodi_Settings('pvrsettings')
        #Open_Kodi_Settings('appearancesettings')
        #xbmc.executebuiltin("ActivateWindow(AddonBrowser)")



def DownloaderClass(url,dest,dlfile, useReq = False):
    dp = xbmcgui.DialogProgress()
    dp.create(AddonTitle,"Downloading & Copying "+dlfile,'')
    if useReq:
        import urllib2
        req = urllib2.Request(url)
        req.add_header('Referer', 'http://wallpaperswide.com/')
        f       = open(dest, mode='wb')
        resp    = urllib2.urlopen(req)
        content = int(resp.headers['Content-Length'])
        size    = content / 100
        total   = 0
        while True:
            if dp.iscanceled():
                raise Exception("Canceled")
                dp.close()
            chunk = resp.read(size)
            if not chunk:
                f.close()
                break
            f.write(chunk)
            total += len(chunk)
            percent = min(100 * total / content, 100)
            dp.update(percent)
    else:
        urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled():
        raise Exception("Canceled")
        dp.close()        

def xEB(t): xbmc.executebuiltin(t)
def xEBb(t): xEB('Skin.SetBool(%s)'%t)
def xEBS(t,n): xEB('Skin.SetString(%s,%s)'%(t,n))
def doSetView(s): xbmc.executebuiltin("Container.SetViewMode(%s)" % settings.getSetting(s))
#def OPEN_URL(url): req=urllib2.Request(url); req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'); response=urllib2.urlopen(req); link=response.read(); response.close(); return link

#-----------------------------------------------------------------------------------------------------------------
#Addon starts here
params=Get_Params()
addon_id=None
audioaddons=None
author=None
buildname=None
data_path=None
description=None
DOB=None
email=None
fanart=None
forum=None
iconimage=None
link=None
local=None
messages=None
mode=None
name=None
posts=None
programaddons=None
provider_name=None
repo_id=None
repo_link=None
skins=None
sources=None
updated=None
unread=None
url=None
version=None
video=None
videoaddons=None
welcometext=None
zip_link=None

try:    addon_id=urllib.unquote_plus(params["addon_id"])
except: pass
try:    adult=urllib.unquote_plus(params["adult"])
except: pass
try:    audioaddons=urllib.unquote_plus(params["audioaddons"])
except: pass
try:    author=urllib.unquote_plus(params["author"])
except: pass
try:    buildname=urllib.unquote_plus(params["buildname"])
except: pass
try:    data_path=urllib.unquote_plus(params["data_path"])
except: pass
try:    description=urllib.unquote_plus(params["description"])
except: pass
try:    DOB=urllib.unquote_plus(params["DOB"])
except: pass
try:    email=urllib.unquote_plus(params["email"])
except: pass
try:    fanart=urllib.unquote_plus(params["fanart"])
except: pass
try:    forum=urllib.unquote_plus(params["forum"])
except: pass
try:    guisettingslink=urllib.unquote_plus(params["guisettingslink"])
except: pass
try:    iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try:    link=urllib.unquote_plus(params["link"])
except: pass
try:    local=urllib.unquote_plus(params["local"])
except: pass
try:    messages=urllib.unquote_plus(params["messages"])
except: pass
try:    mode=str(params["mode"])
except: pass
try:    name=urllib.unquote_plus(params["name"])
except: pass
try:    pictureaddons=urllib.unquote_plus(params["pictureaddons"])
except: pass
try:    posts=urllib.unquote_plus(params["posts"])
except: pass
try:    programaddons=urllib.unquote_plus(params["programaddons"])
except: pass
try:    provider_name=urllib.unquote_plus(params["provider_name"])
except: pass
try:    repo_link=urllib.unquote_plus(params["repo_link"])
except: pass
try:    repo_id=urllib.unquote_plus(params["repo_id"])
except: pass
try:    skins=urllib.unquote_plus(params["skins"])
except: pass
try:    sources=urllib.unquote_plus(params["sources"])
except: pass
try:    updated=urllib.unquote_plus(params["updated"])
except: pass
try:    unread=urllib.unquote_plus(params["unread"])
except: pass
try:    url=urllib.unquote_plus(params["url"])
except: pass
try:    version=urllib.unquote_plus(params["version"])
except: pass
try:    video=urllib.unquote_plus(params["video"])
except: pass
try:    videoaddons=urllib.unquote_plus(params["videoaddons"])
except: pass
try:    zip_link=urllib.unquote_plus(params["zip_link"])
except: pass

print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info 
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
if mode==None or url==None or len(url)<1:
        Categories()
elif mode == 'addon_removal_menu' : Addon_Removal_Menu()
elif mode == 'addonfix'           : addonfix.fixes()
elif mode == 'addonfixes'         : Addon_Fixes()
elif mode == 'addonmenu'          : Addon_Menu()
elif mode == 'addon_settings'     : Addon_Settings()
elif mode == 'backup'             : BACKUP()
elif mode == 'backup_option'      : communitybuilds.Backup_Option()
elif mode == 'backup_restore'     : Backup_Restore()
elif mode == 'adultmenu'          : AdultMenu()
elif mode == 'thirdpartymenu'     : ThirdPartyMenu()
elif mode == 'kmintmenu'          : KMIntMenu()
elif mode == 'buildmenu'          : BuildMenu()
elif mode == 'categories'         : Categories()
elif mode == 'clear_cache'        : Clear_Cache()
elif mode == 'community_backup'   : communitybuilds.Community_Backup()
elif mode == 'community_menu'     : communitybuilds.Community_Menu(url,video)        
elif mode == 'description'        : communitybuilds.Description(name,url,buildname,author,version,description,updated,skins,videoaddons,audioaddons,programaddons,pictureaddons,sources,adult)
elif mode == 'fix_special'        : communitybuilds.Fix_Special(url)
elif mode == 'genres'             : Genres(url)
elif mode == 'grab_addons'        : addons.Grab_Addons(url)
elif mode == 'grab_builds_premium': communitybuilds.Grab_Builds_Premium(url)
elif mode == 'guisettingsfix'     : communitybuilds.GUI_Settings_Fix(url,local)
elif mode == 'guisettings'        : guisettings()   
elif mode == 'hide_passwords'     : extras.Hide_Passwords()
elif mode == 'LocalGUIDialog'     : communitybuilds.Local_GUI_Dialog()
elif mode == 'remove_addon_data'  : Remove_Addon_Data()
elif mode == 'remove_addons'      : extras.Remove_Addons(url)
elif mode == 'remove_build'       : extras.Remove_Build()
elif mode == 'remove_crash_logs'  : Remove_Crash_Logs()
elif mode == 'remove_packages'    : Remove_Packages()
elif mode == 'remove_textures'    : Remove_Textures()
elif mode == 'restore'            : extras.RESTORE()
elif mode == 'restore_backup'     : communitybuilds.Restore_Backup_XML(name,url,description)
elif mode == 'restore_local_CB'   : communitybuilds.Restore_Local_Community()
elif mode == 'restore_local_gui'  : communitybuilds.Restore_Local_GUI()
elif mode == 'restore_option'     : communitybuilds.Restore_Option()
elif mode == 'restore_zip'        : communitybuilds.Restore_Zip_File(url)
elif mode == 'restore_community'  : communitybuilds.Restore_Community(name,url,video,description,skins,guisettingslink)
elif mode == 'showinfo'           : communitybuilds.Show_Info(url)
elif mode == 'SortBy'             : extras.Sort_By(BuildURL,type)
elif mode == 'text_guide'         : news.Text_Guide(name,url)
elif mode == 'tools'              : Tools()     
elif mode == 'unhide_passwords'   : extras.Unhide_Passwords()
elif mode == 'update'             : addons.Update_Repo()
elif mode == 'uploadlog'          : extras.Upload_Log()
elif mode == 'user_info'          : Show_User_Info()
elif mode == 'wipetools'          : Wipe_Tools()
elif mode == 'xbmcversion'        : extras.XBMC_Version(url)
elif mode == 'wipe_xbmc'          : Wipe_Kodi()
elif mode == 'wizard'             : wizard(name,url,description)

###Main Menu Andy
elif mode == 'System_Tweaks'      : System_Tweaks_MENU()
elif mode == 'Extra_Addons'       : Extra_Addons_MENU()
elif mode == 'Extra_Builds'       : Extra_Builds_MENU()
elif mode == 'AdvancedSettings_menu' : AdvancedSettings_MENU()
elif mode == 'Kodi_System'        : Kodi_System_MENU()
elif mode == 'XML_MENU'           : XML_MENU()
elif mode == 'Info_MENU'          : Info_MENU()
elif mode == 'LiveTV'             : LiveTV()
#Maintenance
elif mode == 'kill_kodi'          : killkodi()
elif mode == 'Purge_Packages'     : PURGEPACKAGES()
elif mode == 'get_ip'             : Get_IP()
elif mode == 'AddonBrowser'       : Open_Kodi_Settings('AddonBrowser')
elif mode == 'check_storage'      : CheckPath.CheckPath()
elif mode == 'speed_test'         : Speed_Test_Menu()
elif mode == 'runtest'            : speedtest.runtest(url)
elif mode == 'log'                : extras.Log_Viewer()
elif mode == 'log_upload'         : Upload_Log()
#elif mode == 'help'               : File_Viewer('special://logpath', 'kodi.log')
elif mode == 'help'               : File_Viewer('special://home/addons/'+AddonID, 'help.txt')
elif mode == 'warning'            : File_Viewer('special://home/addons/'+AddonID, 'warning.txt')
#Advancedsettings.xml Menu
elif mode == 'verifyadvancedsettings' : CHECKADVANCEDXML(url,name)
elif mode == 'removeadvancedsettings' : DELETEADVANCEDXML(url)
elif mode == 'add_advancedsettings' : ADVANCEDXML_PROMPTS(url,name,'advancedsettings.xml')
elif mode == 'add_tuxen'          : ADVANCEDXML_PROMPTS(url,name,'advancedsettings.xml')
elif mode == 'add_0cache'         : ADVANCEDXML_PROMPTS(url,name,'advancedsettings.xml')
#Backups zip
elif mode == 'Install_All'        : Install_All()
#Backups full
elif mode == 'Repos_Backup'       : PATH_ADDON_PROMPTS(url, 'Repos', 'home/addons');xbmc.executebuiltin("UpdateAddonRepos")
elif mode == 'Addon_Data_Backup'  : PATH_ADDON_PROMPTS(url, 'Addon_Data', 'profile/addon_data');communitybuilds.Fix_Special(url)
elif mode == 'Addons_Backup'      : ADDONS_ALL()#; xbmc.executebuiltin('SendClick(AddonBrowser, 5)')#PATH_ADDON_PROMPTS(url, 'Addons', 'addons');xbmc.executebuiltin('UpdateLocalAddons')
elif mode == 'XML_All_Backup'     : ADVANCEDXML(url_XML_SOURCES,name,'sources.xml');ADVANCEDXML(url_XML_ADVANCEDSETTINGS,name,'advancedsettings.xml');ADVANCEDXML(url_XML_RSS,name,'RssFeeds.xml');ADVANCEDXML(url_XML_favourites,name,'favourites.xml');dialog = xbmcgui.Dialog();dialog.ok(AddonTitle, "       Done Adding Xmls")
elif mode == 'shortcuts'          : SHORTCUTS(); dialog=xbmcgui.Dialog(); dialog.ok(AddonTitle,"Done Installing Homescreen Shortcuts") 
#XML
elif mode == 'XML_SOURCES'        : ADVANCEDXML_PROMPT(url,name,'sources.xml')
elif mode == 'XML_ADVANCEDSETTINGS':ADVANCEDXML_PROMPT(url,name,'advancedsettings.xml')
elif mode == 'XML_RSS'            : ADVANCEDXML_PROMPT(url,name,'RssFeeds.xml')
elif mode == 'XML_favourites'     : ADVANCEDXML_PROMPT(url,name,'favourites.xml')
elif mode == 'XML_autoexec'       : ADVANCEDXML_PROMPT(url,name,'autoexec.py')
elif mode == 'XML_Database'       : ADVANCEDXML_PROMPT(url,name,'sources.xml');ADVANCEDXML(url_XML_PASSWORDS,name,'passwords.xml');ADVANCEDXML(url_XML_favourites,name,'favourites.xml');PATH_ADDON(url_ZIP_Database, 'Database', 'userdata/Database');PATH_ADDON(url_ZIP_keymaps, 'keymaps', 'userdata/keymaps');dialog = xbmcgui.Dialog();dialog.ok(AddonTitle, "       Done Adding other Xmls")
elif mode == 'view_advancedxml'   : File_Viewer('special://profile', 'advancedsettings.xml')
elif mode == 'view_sources'       : File_Viewer('special://profile', 'sources.xml')
elif mode == 'view_RSSFeeds'      : File_Viewer('special://profile', 'RSSFeeds.xml')
elif mode == 'view_favourites'    : File_Viewer('special://profile', 'favourites.xml')
#Tweaks
elif mode == 'Log_Analyzer'       : LOGANALYZER(url)#58  ?
elif mode == 'modules'            : Install_Modules()
elif mode == 'm3u'                : ADVANCEDXML_PROMPT(url,name,'library/iptv.m3u')
#Addons
elif mode == 'Andy_Repo'            : PATH_ADDON_PROMPTS(url, 'Andy_Repo', 'home/addons')
elif mode == 'Minimal_Dependancies' : DEPENDANCIES_FILE('script.module.addon.common'); DEPENDANCIES_FILE('repository.Andy'); DEPENDANCIES_FILE('plugin.program.forceclose');dialog=xbmcgui.Dialog(); dialog.ok(AddonTitle,"Done Installing DEPENDANCIES") 
elif mode == 'superrepo_isengard_repositories'          : PATH_ADDON_PROMPTS(url, 'superrepo_isengard_repositories', 'home/addons')
elif mode == 'superrepo_isengard_external_repositories' : PATH_ADDON_PROMPTS(url, 'superrepo_isengard_external_repositories', 'home/addons')
elif mode == 'Pulsar'               : PATH_ADDON_PROMPTS(url, 'Pulsar', 'home/addons')
elif mode == 'Plexus'               : PATH_ADDON_PROMPTS(url, 'Plexus', 'home')
elif mode == 'iStream'              : PATH_ADDON_PROMPTS(url, 'iStream', 'home')
#Kodi Settings
elif mode == 'systemsettings'       : Open_Kodi_Settings('settings')
elif mode == 'filemanager'          : Open_Kodi_Settings('filemanager')
elif mode == 'systeminfo'           : Open_Kodi_Settings('systeminfo')
elif mode == 'screencalibration'    : Open_Kodi_Settings('screencalibration')
elif mode == 'servicesettings'      : Open_Kodi_Settings('servicesettings')
elif mode == 'appearancesettings'   : Open_Kodi_Settings('appearancesettings')
elif mode == 'videossettings'       : Open_Kodi_Settings('videossettings')
elif mode == 'musicsettings'        : Open_Kodi_Settings('musicsettings')
elif mode == 'weathersettings'      : Open_Kodi_Settings('weathersettings')
elif mode == 'profiles'             : Open_Kodi_Settings('profiles')
elif mode == 'skinsettings'         : Open_Kodi_Settings('skinsettings')
elif mode == 'pvrsettings'          : Open_Kodi_Settings('pvrsettings')
elif mode == 'iVue'                 : iVue()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
