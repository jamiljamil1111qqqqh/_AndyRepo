import urllib, urllib2, re, xbmcplugin, xbmcgui, xbmc, xbmcaddon, os, sys, time, xbmcvfs
import glob
import shutil
import subprocess

mainurl_epg            = 'https://raw.githubusercontent.com/halikus/_epg/master/'
url_EPG_ADDONINI       = mainurl_epg+'addons.ini'
AddonTitle             = "iVue"
dialog     =  xbmcgui.Dialog()
dp         =  xbmcgui.DialogProgress()

mode='ivue'

################################
###    Fix Ivue              ### 
################################
def ivue():
    #iVue_Fix("script.tvguidetecbox.Networks",url_EPG_ADDONINI,mainurl_epg + '_iVue_settings.xml')
    #iVue_Fix("script.tvguidetecbox.NetworksExtra",url_EPG_ADDONINI,mainurl_epg + '_iVue_settings.xml')  
    #iVue_Fix("script.tvguidetecbox.UK",url_EPG_ADDONINI,mainurl_epg + '_iVue_settings.xml')       
    #iVue_Fix("script.tvguidetecbox",url_EPG_ADDONINI,mainurl_epg + '_iVue_settings.xml')
    
    addon_data_delete_file('plugin.video.StalkerAndy', 'http_portal_iptvprivateserver_tv')
    addon_data_delete_file('plugin.video.StalkerAndy', 'http_portal_iptvprivateserver_tv-genres')
    addon_data_delete_file('plugin.video.StalkerAndy2', 'http_portal_iptvprivateserver_tv')
    addon_data_delete_file('plugin.video.StalkerAndy2', 'http_portal_iptvprivateserver_tv-genres') 
    addon_data_delete_file('plugin.video.Cypher-S-hack', 'http_portal_iptvprivateserver_tv-genres')
    addon_data_delete_file('plugin.video.i4atv', 'http_mw1_iptv66_tv')
    addon_data_delete_file('plugin.video.i4atv', 'http_mw1_iptv66_tv-genres')
    addon_data_delete_file('plugin.video.stalker', 'http_portal_iptvrocket_tv')
    addon_data_delete_file('plugin.video.stalker', 'http_portal_iptvrocket_tv-genres')
    addon_data_delete_file('plugin.video.stalkerTv', 'http_portal_iptvrocket_tv')
    addon_data_delete_file('plugin.video.stalkerTv', 'http_portal_iptvrocket_tv-genres')       
    addon_data_delete_file('plugin.video.Wild TV-Stalker', 'http_portal_iptvrocket_tv')
    addon_data_delete_file('plugin.video.Wild TV-Stalker', 'http_portal_iptvrocket_tv-genres')       
    
    DELETECACHE()
    
    dialog = xbmcgui.Dialog()
    dialog.ok(AddonTitle, "Done fixing IPTV")  
#
def addon_data_delete_file(addon, filedelete):
    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, filedelete)
    try:
       os.remove(lib)
    except:
       pass
#       
def iVue_Fix(addon,url1,url2):
    #pluginpath = os.path.exists(xbmc.translatePath(os.path.join('special://profile','addon_data',addon,"settings.xml")))   
    #if pluginpath: ADVANCEDXML(url2,addon,'addon_data/'+addon+'/settings.xml')   
     
    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'source5.db')
    try:
       os.remove(lib)
    except:
       pass

    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'guide.xml')
    try:
       os.remove(lib)
    except:
       pass

    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'master.xml')
    try:
       os.remove(lib)
    except:
       pass

    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'Sports.xml')
    try:
       os.remove(lib)
    except:
       pass

    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'Networks.xml')
    try:
       os.remove(lib)
    except:
       pass

    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'Stalker.xml')
    try:
       os.remove(lib)
    except:
       pass

       
    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'addons.ini')
    try:
       os.remove(lib)
    except:
       pass
    path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data',addon))
    lib=os.path.join(path, 'addons.ini')
    try:
       DownloaderClass(url1,lib,addon)
       time.sleep(1)
    except:
       pass


def ADVANCEDXML(url,name,file):
    #import advancedsettings
    from addon.common.net import Net
    net=Net()
    #path = xbmc.translatePath(os.path.join('special://home/userdata',''))
    path = xbmc.translatePath(os.path.join('special://profile',''))
    advance=os.path.join(path, file)
    bak=os.path.join(path, file+'.bak')
    if os.path.exists(bak)==False:
        print '### '+AddonTitle+' - '+file+'###'
        #path = xbmc.translatePath(os.path.join('special://home/userdata',''))
        path = xbmc.translatePath(os.path.join('special://profile',''))
        advance=os.path.join(path, file)
        try:
            os.remove(advance)
            print '=== Maintenance Tool - REMOVING    '+str(advance)+'    ==='
        except:
            pass
        link=net.http_GET(url).content
        a = open(advance,"w")
        a.write(link)
        a.close()
        print '=== Maintenance Tool - WRITING NEW    '+str(advance)+'    ==='
    else:
        print '###'+AddonTitle+' - '+file+'###'
        #path = xbmc.translatePath(os.path.join('special://home/userdata',''))
        path = xbmc.translatePath(os.path.join('special://profile',''))
        advance=os.path.join(path, file)
        try:
            os.remove(advance)
            print '=== Maintenance Tool - REMOVING    '+str(advance)+'    ==='
        except:
            pass
        link=net.http_GET(url).content
        a = open(advance,"w")
        a.write(link)
        a.close()
        print '=== Maintenance Tool - WRITING NEW    '+str(advance)+'    ==='


def DELETECACHE():
    print '###DELETING STANDARD CACHE###'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete KODI Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
    
	#addDir('[COLOR yellow]*** All Done Now Press Back ***[/COLOR]','0',0,icon,'',fanart)
	xbmc.executebuiltin('Container.SetViewMode(50)')




def DownloaderClass(url,dest,dlfile, useReq = False):
    dp = xbmcgui.DialogProgress()
    dp.create(AddonTitle,"Downloading & Copying "+dlfile,'')
    if useReq:
        import urllib2
        req = urllib2.Request(url)
        req.add_header('Referer', 'http://wallpaperswide.com/')
        f       = open(dest, mode='wb')
        resp    = urllib2.urlopen(req)
        content = int(resp.headers['Content-Length'])
        size    = content / 100
        total   = 0
        while True:
            if dp.iscanceled():
                raise Exception("Canceled")
                dp.close()
            chunk = resp.read(size)
            if not chunk:
                f.close()
                break
            f.write(chunk)
            total += len(chunk)
            percent = min(100 * total / content, 100)
            dp.update(percent)
    else:
        urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled():
        raise Exception("Canceled")
        dp.close()        


if mode=='ivue' : ivue()