# plugin.video.stalker

Kodi Stalker video add-on - all platforms

This is a clone of iptv stalker and will certainly stop working if it does stop working i will update it and post it on my youtube channel 
just search youtube for Inside 4ndroid. Please dont complain or bitch about it not working if you want a fully working iptv service the make 
a donation and get the premium mac for yourself.
